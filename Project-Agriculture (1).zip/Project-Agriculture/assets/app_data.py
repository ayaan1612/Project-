"""
Static text content for the agricultural recommendation platform
"""

# Introduction text for the home page
intro_text = """
## Welcome to Smart Agriculture Platform

This interactive platform helps Indian farmers make informed decisions about crop selection based on their soil 
type and growing season. By leveraging scientific data and 3D visualizations, we provide personalized 
recommendations to improve crop yields, reduce economic risks, and promote sustainable farming practices.

### How It Works:

1. **Select your soil type** - Choose from common Indian soil types with interactive 3D models
2. **Select your growing season** - Kharif, Rabi, or Summer
3. **Get personalized recommendations** - See which crops are best suited for your conditions
4. **Explore in 3D** - Visualize crops and their growth patterns
5. **Learn best practices** - Get cultivation tips specific to your selection

Our platform supports the vision of Viksit Bharat 2047 by empowering farmers with technology and knowledge for a 
prosperous agricultural future.
"""

# About page text
about_text = """
## About Smart Agriculture - Viksit Bharat 2047

Small and marginal farmers in India continuously face difficulties in farming primarily due to limited exposure to 
localized agricultural information, especially regarding proper crop choices based on soil type and season. This 
limits their ability to make timely and good choices, inevitably leading to poor crop selections, lower yields, 
economic losses, and poor ecological practices.

### Our Mission

Smart Agriculture is designed to address these challenges by providing accessible, personalized suggestions for 
farmers based on their specific soil type and upcoming growing season. By combining scientific data with interactive 
3D visualizations, we make complex agricultural information more accessible and engaging.

### Technology Meets Agriculture

Our platform uses advanced 3D modeling and data analytics to help farmers visualize different soil types, crops, 
and growing conditions. This visual approach makes it easier to understand the recommendations and implement them 
in real-world farming scenarios.

### Impact on Indian Agriculture

* **Improved Yields**: Science-based crop selection leads to better productivity
* **Economic Security**: Reducing crop failures provides more stable income for farmers
* **Sustainable Practices**: Promoting environmentally appropriate farming methods
* **Knowledge Transfer**: Making agricultural science accessible to all farmers
* **Digital Inclusion**: Bringing technology benefits to small and marginal farmers

### Vision for Viksit Bharat 2047

This platform supports India's vision for becoming a developed nation by 2047 by transforming agricultural 
practices, improving rural livelihoods, and ensuring food security through technology-enabled smart farming.
"""

# Footer text
footer_text = """
<div style="text-align: center; padding: 10px;">
    <p><strong>Smart Agriculture - Viksit Bharat 2047</strong> | Empowering farmers through technology</p>
    <p>© 2023 Smart Agriculture Initiative | Contact: info@smartagriculture.org</p>
</div>
"""
