import streamlit as st
import pandas as pd
import plotly.express as px
from data.crop_data import get_recommended_crops
from streamlit_lottie import st_lottie
import requests
import json
import plotly.graph_objects as go
from streamlit_card import card

# Animation URLs for different crop types
CROP_ANIMATIONS = {
    "Rice": "https://assets9.lottiefiles.com/packages/lf20_6e0qqtpa.json",
    "Wheat": "https://assets3.lottiefiles.com/private_files/lf30_qnpfxvgj.json",
    "Cotton": "https://assets3.lottiefiles.com/private_files/lf30_l6c6fuos.json",
    "Sugarcane": "https://assets6.lottiefiles.com/packages/lf20_vmoudzgx.json",
    "Maize": "https://assets6.lottiefiles.com/packages/lf20_vmoudzgx.json",
    "default": "https://assets9.lottiefiles.com/packages/lf20_kU51J1.json"
}

def load_lottie_url(url):
    """Load a Lottie animation from URL"""
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None

def create_crop_3d_model(crop_name):
    """Generate a modern visualization for a crop"""
    
    crop_heights = {
        "Rice": [0, 0.2, 0.5, 0.7, 0.9, 1.0],
        "Wheat": [0, 0.3, 0.6, 0.8, 0.9, 1.0],
        "Cotton": [0, 0.1, 0.4, 0.7, 0.9, 1.2],
        "Sugarcane": [0, 0.2, 0.6, 1.0, 1.5, 2.0],
        "Maize": [0, 0.3, 0.7, 1.2, 1.8, 2.2],
        # Default growth pattern
        "default": [0, 0.2, 0.5, 0.8, 1.0, 1.2]
    }
    
    crop_colors = {
        "Rice": "#78C091",
        "Wheat": "#EFD469",
        "Cotton": "#F4F4F4",
        "Sugarcane": "#A1D39F",
        "Maize": "#F9E076",
        # Default color
        "default": "#1DB954"
    }
    
    # Get growth pattern and color for the crop
    heights = crop_heights.get(crop_name, crop_heights["default"])
    color = crop_colors.get(crop_name, crop_colors["default"])
    
    # Create growth stages for x-axis
    stages = ["Seedling", "Early Growth", "Mid Growth", "Late Growth", "Mature", "Harvest"]
    
    # Create enhanced area chart for better visualization
    fig = go.Figure()
    
    # Add filled area under the curve
    fig.add_trace(go.Scatter(
        x=stages,
        y=heights,
        fill='tozeroy',
        fillcolor=f"rgba({','.join(str(int(i * 255)) for i in px.colors.hex_to_rgb(color)[:3])},0.3)",
        line=dict(color=color, width=0),
        showlegend=False
    ))
    
    # Add line with markers
    fig.add_trace(go.Scatter(
        x=stages,
        y=heights,
        mode='lines+markers',
        line=dict(color=color, width=4, shape='spline'),
        marker=dict(size=10, color=color, line=dict(width=2, color='white')),
        name=crop_name
    ))
    
    # Customize the chart
    fig.update_layout(
        height=250,
        margin=dict(l=20, r=20, t=40, b=20),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(
            showgrid=False,
            showline=True,
            linecolor='rgba(255,255,255,0.3)',
            tickfont=dict(color='white')
        ),
        yaxis=dict(
            showgrid=False,
            zeroline=False,
            showline=True,
            linecolor='rgba(255,255,255,0.3)',
            tickfont=dict(color='white'),
            title=dict(text="Height (m)", font=dict(color='white'))
        ),
        title=dict(
            text=f"{crop_name} Growth Pattern",
            font=dict(size=18, color='white')
        ),
        hovermode="x unified",
        hoverlabel=dict(
            bgcolor="#212121",
            font_size=12,
            font_color="white"
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return fig

def show_recommendations(soil_type, season):
    """Show crop recommendations based on soil type and season"""
    
    st.markdown(f"<h1 style='text-align: center; animation: fadeIn 1.5s;'>Recommended Crops for {soil_type} in {season} Season</h1>", unsafe_allow_html=True)
    
    # Add custom CSS for animations and styling
    st.markdown("""
    <style>
    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    
    @keyframes pulseScale {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    
    @keyframes slideUp {
        0% { transform: translateY(20px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes borderPulse {
        0% { border-color: rgba(29, 185, 84, 0.5); }
        50% { border-color: rgba(29, 185, 84, 1); }
        100% { border-color: rgba(29, 185, 84, 0.5); }
    }
    
    .crop-card {
        background-color: #212121;
        border-radius: 15px;
        padding: 20px;
        margin: 15px 0;
        animation: slideUp 0.8s ease-out forwards;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease;
        border: 1px solid #333;
    }
    
    .crop-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3);
        border-color: #1DB954;
    }
    
    .crop-title {
        font-size: 24px;
        font-weight: bold;
        color: white;
        text-align: center;
        margin-bottom: 15px;
    }
    
    .suitability-label {
        font-size: 18px;
        color: white;
        margin: 10px 0;
    }
    
    .suitability-value {
        display: inline-block;
        background-color: #1DB954;
        color: white;
        font-weight: bold;
        padding: 4px 12px;
        border-radius: 20px;
        float: right;
    }
    
    .ideal-badge {
        background-color: #1DB954;
        color: white;
        font-weight: bold;
        padding: 8px 16px;
        border-radius: 20px;
        text-align: center;
        margin: 10px auto;
        display: block;
        width: fit-content;
        animation: pulseScale 2s infinite;
        box-shadow: 0 0 10px rgba(29, 185, 84, 0.5);
    }
    
    .property-label {
        color: #999;
        font-size: 14px;
    }
    
    .property-value {
        color: white;
        font-weight: bold;
        font-size: 16px;
    }
    
    .crop-property {
        margin: 8px 0;
        display: flex;
        justify-content: space-between;
    }
    
    .growing-tips {
        background-color: #333;
        padding: 10px;
        border-radius: 10px;
        margin-top: 15px;
        border-left: 3px solid #1DB954;
    }
    
    .progress-container {
        background-color: #333;
        border-radius: 10px;
        height: 10px;
        margin: 15px 0;
        overflow: hidden;
    }
    
    .progress-bar {
        background-color: #1DB954;
        height: 100%;
        border-radius: 10px;
        width: 0%;
        transition: width 1s ease-in-out;
    }
    </style>
    
    <script>
    // Animation for progress bars
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            const progressBars = document.querySelectorAll('.progress-bar');
            progressBars.forEach(bar => {
                const width = bar.getAttribute('data-width');
                bar.style.width = width;
            });
        }, 300);
    });
    </script>
    """, unsafe_allow_html=True)
    
    # Get recommended crops
    recommended_crops = get_recommended_crops(soil_type, season)
    
    if not recommended_crops:
        st.warning("No specific recommendations found for this combination. Please try another selection.")
        return
    
    # Display crops in a grid
    cols = st.columns(3)
    
    for i, crop in enumerate(recommended_crops):
        with cols[i % 3]:
            # Apply staggered animation delay
            delay = i * 0.2
            
            # Create crop card with animation
            st.markdown(f"""
            <div class="crop-card" style="animation-delay: {delay}s">
                <h3 class="crop-title">{crop["name"]}</h3>
            </div>
            """, unsafe_allow_html=True)
            
            # Try to load Lottie animation for the crop
            animation_url = CROP_ANIMATIONS.get(crop["name"], CROP_ANIMATIONS["default"])
            animation_data = load_lottie_url(animation_url)
            
            if animation_data:
                st_lottie(animation_data, height=180, key=f"crop_anim_{i}")
            else:
                # Fallback to plotly chart if animation fails
                fig = create_crop_3d_model(crop["name"])
                st.plotly_chart(fig, use_container_width=True)
            
            # Show suitability score with visual indicator
            st.markdown(f"""
            <div class="suitability-label">
                Suitability <span class="suitability-value">{crop['suitability']}/10</span>
            </div>
            
            <div class="progress-container">
                <div class="progress-bar" data-width="{crop['suitability']*10}%"></div>
            </div>
            """, unsafe_allow_html=True)
            
            # Create nicely styled expander for crop details
            with st.expander("Crop Details"):
                st.markdown(f"""
                <div class="crop-property">
                    <span class="property-label">Water Requirements:</span>
                    <span class="property-value">{crop['water_req']}</span>
                </div>
                <div class="crop-property">
                    <span class="property-label">Growth Period:</span>
                    <span class="property-value">{crop['growth_period']}</span>
                </div>
                <div class="crop-property">
                    <span class="property-label">Economic Value:</span>
                    <span class="property-value">{crop['economic_value']}</span>
                </div>
                """, unsafe_allow_html=True)
            
            # Growing tips with better styling
            with st.expander("Growing Tips"):
                st.markdown(f"""
                <div class="growing-tips">
                {crop["growing_tips"]}
                </div>
                """, unsafe_allow_html=True)
            
            # Show 'ideal choice' badge for high suitability crops
            if crop['suitability'] >= 8:
                st.markdown("""
                <div class="ideal-badge">
                    ✅ Ideal Choice
                </div>
                """, unsafe_allow_html=True)
