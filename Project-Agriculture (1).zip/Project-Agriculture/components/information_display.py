import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from data.soil_data import get_soil_info
from streamlit_lottie import st_lottie
import requests

# Animation URLs
LOTTIE_SOIL = "https://assets1.lottiefiles.com/packages/lf20_ntvn4faj.json"
LOTTIE_FARMING = "https://assets2.lottiefiles.com/packages/lf20_oyi9a28x.json"
LOTTIE_SUSTAINABLE = "https://assets9.lottiefiles.com/packages/lf20_ebyt2fkr.json"

def load_lottie_url(url):
    """Load a Lottie animation from URL"""
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None

def show_info_panel(soil_type, season=None):
    """Display educational information about soil and crop compatibility"""
    
    st.markdown("""
    <div style="text-align: center; animation: fadeIn 1.2s ease;">
        <h2 style="color: white; margin-bottom: 20px; font-size: 32px; font-weight: bold;">
            Agricultural Knowledge Hub
        </h2>
        <p style="color: #999; font-size: 16px;">
            Detailed information to help you make the best farming decisions
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Add custom CSS for animations and styling
    st.markdown("""
    <style>
    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    
    @keyframes slideInUp {
        0% { transform: translateY(20px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes glowPulse {
        0% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.3); }
        50% { box-shadow: 0 0 16px rgba(29, 185, 84, 0.6); }
        100% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.3); }
    }
    
    /* Custom tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 10px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: #212121;
        border-radius: 5px 5px 0 0;
        gap: 10px;
        padding-top: 10px;
        padding-bottom: 10px;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: #1DB954 !important;
        color: white;
        font-weight: bold;
    }
    
    /* Card styling */
    .info-block {
        background-color: #212121;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        animation: fadeIn 1s ease;
    }
    
    .info-block:hover {
        box-shadow: 0 6px 12px rgba(0,0,0,0.3);
        transform: translateY(-2px);
        transition: all 0.3s ease;
    }
    
    .soil-badge {
        display: inline-block;
        background: linear-gradient(90deg, #1DB954, #1ed760);
        color: white;
        font-weight: bold;
        padding: 5px 12px;
        border-radius: 20px;
        margin-bottom: 15px;
    }
    
    .property-card {
        background-color: #333;
        border-radius: 8px;
        padding: 10px 15px;
        margin-bottom: 10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-left: 3px solid #1DB954;
    }
    
    .property-label {
        color: #999;
        font-size: 14px;
    }
    
    .property-value {
        background-color: #1DB954;
        color: white;
        font-weight: bold;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 14px;
    }
    
    .practice-card {
        background-color: #1a1a1a;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        border-left: 3px solid #1DB954;
        transition: transform 0.3s ease;
    }
    
    .practice-card:hover {
        transform: translateY(-5px);
    }
    
    .practice-title {
        color: white;
        font-weight: bold;
        margin-bottom: 10px;
        font-size: 18px;
    }
    
    .practice-content {
        color: #ccc;
        font-size: 14px;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Get detailed soil information
    soil_info = get_soil_info(soil_type)
    
    # Create tabs for different information sections with icons
    tab1, tab2, tab3 = st.tabs([
        "🌱 Soil Information", 
        "🚜 Cultivation Practices", 
        "♻️ Sustainable Farming"
    ])
    
    with tab1:
        # Animation for soil tab
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Soil type header
            st.markdown(f"""
            <div style="animation: fadeIn 1s ease;">
                <div class="soil-badge">{soil_type}</div>
                <div class="info-block">
                    {soil_info["description"]}
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Soil properties with enhanced display
            st.markdown("""
            <div style="font-size: 20px; font-weight: bold; margin: 15px 0; color: white; animation: fadeIn 1.2s ease;">
                Soil Properties
            </div>
            """, unsafe_allow_html=True)
            
            properties = {
                "pH Level": soil_info["properties"]["ph"],
                "Organic Matter": soil_info["properties"]["organic_matter"],
                "Water Retention": soil_info["properties"]["water_retention"],
                "Nutrient Content": soil_info["properties"]["nutrient_content"]
            }
            
            # Create a more visually appealing display of properties
            for prop, value in properties.items():
                st.markdown(f"""
                <div class="property-card">
                    <span class="property-label">{prop}</span>
                    <span class="property-value">{value}</span>
                </div>
                """, unsafe_allow_html=True)
        
        with col2:
            # Try to load soil animation
            lottie_soil = load_lottie_url(LOTTIE_SOIL)
            if lottie_soil:
                st_lottie(lottie_soil, height=200, key="soil_animation")
            
            # Enhanced soil composition chart
            composition = soil_info["composition"]
            
            # Create the chart with improved styling
            fig = go.Figure(data=[go.Pie(
                labels=list(composition.keys()),
                values=list(composition.values()),
                hole=.4,
                marker=dict(
                    colors=['#1DB954', '#4CAF50', '#8BC34A', '#CDDC39', '#AFB42B'],
                    line=dict(color='#121212', width=2)
                ),
                textinfo='label+percent',
                textfont=dict(size=12, color='white'),
                insidetextorientation='radial'
            )])
            
            fig.update_layout(
                title=dict(
                    text="Soil Composition",
                    font=dict(size=20, color='white'),
                    x=0.5
                ),
                paper_bgcolor='rgba(0,0,0,0)',
                plot_bgcolor='rgba(0,0,0,0)',
                margin=dict(t=50, b=30, l=10, r=10),
                showlegend=False,
                height=300,
                annotations=[dict(
                    text='Texture',
                    font=dict(size=12, color='white'),
                    showarrow=False,
                    x=0.5,
                    y=0.5
                )]
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        col1, col2 = st.columns([3, 1])
        
        with col2:
            # Try to load farming animation
            lottie_farming = load_lottie_url(LOTTIE_FARMING)
            if lottie_farming:
                st_lottie(lottie_farming, height=200, key="farming_animation")
        
        with col1:
            # Header with season information
            if season:
                st.markdown(f"""
                <div style="animation: fadeIn 1s ease;">
                    <div class="soil-badge">{season} Season</div>
                    <h3 style="color: white; margin-bottom: 20px;">Cultivation Practices for {soil_type}</h3>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style="animation: fadeIn 1s ease;">
                    <h3 style="color: white; margin-bottom: 20px;">General Cultivation Practices for {soil_type}</h3>
                </div>
                """, unsafe_allow_html=True)
        
        # Display cultivation practices with nicer formatting
        st.markdown(f"""
        <div class="info-block" style="animation-delay: 0.2s;">
            {soil_info["cultivation_practices"]}
        </div>
        """, unsafe_allow_html=True)
        
        # Create columns for the different aspects of cultivation
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            <div class="practice-card" style="animation-delay: 0.3s;">
                <div class="practice-title">💧 Water Management</div>
                <div class="practice-content">
            """, unsafe_allow_html=True)
            st.markdown(soil_info["water_management"])
            st.markdown("</div></div>", unsafe_allow_html=True)
            
            st.markdown("""
            <div class="practice-card" style="animation-delay: 0.5s;">
                <div class="practice-title">🚜 Soil Preparation</div>
                <div class="practice-content">
            """, unsafe_allow_html=True)
            st.markdown(soil_info["soil_preparation"])
            st.markdown("</div></div>", unsafe_allow_html=True)
        
        with col2:
            st.markdown("""
            <div class="practice-card" style="animation-delay: 0.4s;">
                <div class="practice-title">🌱 Fertilizer Application</div>
                <div class="practice-content">
            """, unsafe_allow_html=True)
            st.markdown(soil_info["fertilizer_recommendations"])
            st.markdown("</div></div>", unsafe_allow_html=True)
            
            st.markdown("""
            <div class="practice-card" style="animation-delay: 0.6s;">
                <div class="practice-title">⚠️ Common Challenges</div>
                <div class="practice-content">
            """, unsafe_allow_html=True)
            st.markdown(soil_info["common_issues"])
            st.markdown("</div></div>", unsafe_allow_html=True)
    
    with tab3:
        col1, col2 = st.columns([3, 1])
        
        with col2:
            # Try to load sustainable farming animation
            lottie_sustainable = load_lottie_url(LOTTIE_SUSTAINABLE)
            if lottie_sustainable:
                st_lottie(lottie_sustainable, height=200, key="sustainable_animation")
        
        with col1:
            st.markdown("""
            <div style="animation: fadeIn 1s ease;">
                <h3 style="color: white; margin-bottom: 10px;">Sustainable Farming Practices</h3>
            </div>
            
            <div class="info-block">
                Sustainable agriculture practices help maintain soil health, conserve water, reduce chemical inputs, 
                and promote biodiversity while ensuring economic viability for farmers. These practices are especially 
                important for long-term soil health and farm productivity.
            </div>
            """, unsafe_allow_html=True)
        
        # Create expandable sections for sustainable practices with better styling
        practices = [
            {
                "name": "Crop Rotation",
                "icon": "🔄",
                "content": """
                **Crop rotation** involves growing different types of crops in the same area across seasons. 
                This practice helps in managing soil fertility, controlling pests and diseases, and reducing soil erosion.
                
                For your soil type, consider the following rotation pattern:
                1. Start with a legume crop to fix nitrogen
                2. Follow with a cereal crop to use the fixed nitrogen
                3. Then plant a vegetable or cash crop
                4. Return to the legume crop to replenish soil nutrients
                """
            },
            {
                "name": "Cover Cropping",
                "icon": "🌿",
                "content": """
                **Cover crops** are planted to cover the soil rather than for harvest. They help prevent soil erosion, 
                improve soil health, enhance water availability, and control weeds.
                
                Recommended cover crops for your soil type:
                - Mustard
                - Clover
                - Alfalfa
                - Buckwheat
                """
            },
            {
                "name": "Integrated Pest Management (IPM)",
                "icon": "🐞",
                "content": """
                **Integrated Pest Management (IPM)** is an ecosystem-based strategy that focuses on long-term prevention 
                of pests through a combination of techniques such as biological control, habitat manipulation, and use 
                of resistant crop varieties.
                
                IPM strategies for common pests in your region:
                1. Regular monitoring of crops for pest problems
                2. Using pest-resistant varieties when available
                3. Employing beneficial insects as natural predators
                4. Using pesticides only when necessary and in targeted applications
                """
            },
            {
                "name": "Water Conservation",
                "icon": "💧",
                "content": """
                **Water conservation** techniques help maximize water use efficiency in agriculture, reducing water waste 
                and ensuring availability during dry periods.
                
                Effective water conservation methods for your soil type:
                - Drip irrigation
                - Mulching
                - Rainwater harvesting
                - Contour farming
                - Scheduled irrigation based on crop needs
                """
            }
        ]
        
        # Display practices in a grid
        cols = st.columns(2)
        
        for i, practice in enumerate(practices):
            with cols[i % 2]:
                with st.expander(f"{practice['icon']} {practice['name']}"):
                    st.markdown(practice["content"])
        
        # Add an attractive callout about climate-smart agriculture
        st.markdown("""
        <div style="background: linear-gradient(90deg, #1a1a1a, #212121); padding: 20px; border-radius: 10px; 
                   border-left: 4px solid #1DB954; margin-top: 20px; animation: glowPulse 3s infinite;">
            <div style="display: flex; align-items: center;">
                <div style="font-size: 30px; margin-right: 15px;">🌍</div>
                <div>
                    <div style="font-weight: bold; font-size: 18px; margin-bottom: 5px; color: white;">
                        Climate-Smart Agriculture (CSA)
                    </div>
                    <div style="color: #ccc; font-size: 14px;">
                        CSA helps farmers adapt to climate change while reducing greenhouse gas emissions.
                        Consider practices like agroforestry, reduced tillage, and precision agriculture to make your farm more resilient.
                    </div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
