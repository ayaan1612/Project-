import streamlit as st
import plotly.graph_objects as go
from data.season_data import seasons
from streamlit_lottie import st_lottie
import requests
import random

# Animation URLs for different seasons
SEASON_ANIMATIONS = {
    "Kharif": "https://assets3.lottiefiles.com/packages/lf20_JYyqZL.json",  # Monsoon/rain animation
    "Rabi": "https://assets7.lottiefiles.com/packages/lf20_gvv0tDai3k.json",  # Winter/snowflake animation
    "Summer": "https://assets2.lottiefiles.com/packages/lf20_xlkxtom9.json"   # Sun/hot animation
}

def load_lottie_url(url):
    """Load a Lottie animation from URL"""
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None

def create_seasonal_icon(season):
    """Create a seasonal icon/visual for the selected season"""
    
    # Season colors and symbols
    season_config = {
        "Kharif": {"color": "#1DB954", "symbol": "☀️"},  # Green for monsoon/summer crops
        "Rabi": {"color": "#FFC107", "symbol": "❄️"},    # Yellow for winter crops
        "Summer": {"color": "#FF5722", "symbol": "☀️"}   # Orange for summer crops
    }
    
    config = season_config.get(season, {"color": "#9E9E9E", "symbol": "🌱"})
    
    # Create a gauge chart to represent the season
    fig = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = 100,
        domain = {'x': [0, 1], 'y': [0, 1]},
        gauge = {
            'axis': {'range': [0, 100], 'visible': False},
            'bar': {'color': config["color"]},
            'bgcolor': "rgba(0,0,0,0)",
            'borderwidth': 0,
            'steps': [
                {'range': [0, 100], 'color': 'rgba(0,0,0,0)'}
            ]
        },
        title = {'text': config["symbol"], 'font': {'size': 40}},
        number = {'valueformat': ' ', 'font': {'size': 1}, 'suffix': ''}
    ))
    
    # Customize the layout
    fig.update_layout(
        margin=dict(l=10, r=10, b=10, t=30),
        height=150,
        width=150,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )
    
    return fig

def season_selector():
    """Component for selecting growing season with visualizations"""
    
    st.markdown("<h1 style='text-align: center; animation: fadeIn 1.5s;'>Select Growing Season</h1>", unsafe_allow_html=True)
    
    # Add custom CSS for animations and styling
    st.markdown("""
    <style>
    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    
    @keyframes slideInFromRight {
        0% { transform: translateX(50px); opacity: 0; }
        100% { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes floatUpDown {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }
    
    @keyframes glowPulse {
        0% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.5); }
        50% { box-shadow: 0 0 20px rgba(29, 185, 84, 0.8); }
        100% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.5); }
    }
    
    .season-card {
        background-color: #212121;
        border-radius: 15px;
        padding: 20px;
        margin: 10px 0;
        animation: slideInFromRight 0.6s ease-out forwards;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    
    .season-card:hover {
        transform: translateY(-5px) scale(1.02);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
    }
    
    .season-title {
        font-size: 24px;
        font-weight: bold;
        text-align: center;
        margin-bottom: 10px;
        color: white;
    }
    
    .months-tag {
        background-color: #333333;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        display: inline-block;
        margin-bottom: 15px;
        animation: fadeIn 1s;
    }
    
    .season-animation {
        animation: floatUpDown 3s ease-in-out infinite;
    }
    
    .season-selected {
        border: 2px solid #1DB954;
        animation: glowPulse 2s infinite;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Get current selection
    selected_season = st.session_state.selected_season
    
    # Display season options
    cols = st.columns(3)
    
    # Create clickable season cards
    for i, season in enumerate(seasons):
        with cols[i]:
            # Apply different animation delays to create staggered animation
            delay = i * 0.2
            selected_class = "season-selected" if selected_season == season["name"] else ""
            
            st.markdown(f"""
            <div class="season-card {selected_class}" style="animation-delay: {delay}s">
                <div class="season-title">{season["name"]}</div>
                <div style="text-align: center;">
                    <div class="months-tag">{season['months']}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # Try to load Lottie animation
            animation_url = SEASON_ANIMATIONS.get(season["name"])
            animation_data = load_lottie_url(animation_url)
            
            if animation_data:
                st_lottie(
                    animation_data, 
                    height=150, 
                    key=f"season_animation_{i}",
                    quality="high",
                    speed=1
                )
            else:
                # Fallback to the plotly chart if animation fails
                fig = create_seasonal_icon(season["name"])
                st.plotly_chart(fig, use_container_width=True)
            
            with st.expander("Season Details"):
                st.write(season["description"])
            
            # Selection button with custom styling
            button_key = f"season_button_{i}"
            if st.button("Select", key=button_key, use_container_width=True,
                      disabled=(selected_season == season["name"])):
                st.session_state.selected_season = season["name"]
                st.session_state.show_results = False
                st.rerun()
                
            # Show selected indicator with animation
            if selected_season == season["name"]:
                st.markdown("""
                <div style="background-color: #1DB954; color: white; padding: 10px; 
                border-radius: 5px; text-align: center; animation: glowPulse 2s infinite;">
                ✅ Selected
                </div>
                """, unsafe_allow_html=True)
