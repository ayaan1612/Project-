import streamlit as st
import plotly.graph_objects as go
from data.soil_data import soil_types
from streamlit_card import card
from streamlit_lottie import st_lottie
import json
import requests
import numpy as np

# Animation JSON files for soil types
SOIL_ANIMATIONS = {
    "Alluvial Soil":
    "https://assets4.lottiefiles.com/packages/lf20_va37dlst.json",
    "Black Soil":
    "https://assets3.lottiefiles.com/packages/lf20_jw3aymn0.json",
    "Red Soil": "https://assets9.lottiefiles.com/packages/lf20_p3yzfkul.json",
    "Laterite Soil":
    "https://assets9.lottiefiles.com/packages/lf20_p3yzfkul.json",
    "Desert Soil":
    "https://assets3.lottiefiles.com/packages/lf20_pmgmwzeu.json",
    "Mountain Soil":
    "https://assets9.lottiefiles.com/packages/lf20_niopwvbd.json"
}


def load_lottie_url(url):
    """Load a Lottie animation from URL"""
    try:
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return r.json()
    except:
        return None


def create_3d_soil_model(soil_type):
    """Create a 3D model representation for the selected soil type"""

    # Different colors for different soil types
    soil_colors = {
        "Alluvial Soil": "#D2B48C",
        "Black Soil": "#32312E",
        "Red Soil": "#A52A2A",
        "Laterite Soil": "#FF4500",
        "Desert Soil": "#EDC9AF",
        "Mountain Soil": "#8B4513"
    }

    color = soil_colors.get(soil_type, "#D2B48C")

    # Create a better soil visualization using surface plot
    # Generate grid data for the surface
    x = np.linspace(-1, 1, 20)
    y = np.linspace(-1, 1, 20)
    x_grid, y_grid = np.meshgrid(x, y)

    # Create different surface patterns for each soil type
    if soil_type == "Alluvial Soil":
        # Smooth terrain with gentle ripples for alluvial soil
        z_grid = 0.1 * np.sin(5 * x_grid) + 0.1 * np.cos(5 * y_grid)
    elif soil_type == "Black Soil":
        # Cracked pattern for black soil
        z_grid = 0.1 * (np.sin(8 * x_grid) * np.cos(8 * y_grid))
    elif soil_type == "Red Soil":
        # Undulating surface for red soil
        z_grid = 0.15 * np.sin(3 * x_grid**2 + 3 * y_grid**2)
    elif soil_type == "Laterite Soil":
        # Porous texture for laterite soil
        z_grid = 0.1 * np.sin(10 * x_grid) + 0.1 * np.sin(10 * y_grid)
    elif soil_type == "Desert Soil":
        # Sand dune pattern for desert soil
        z_grid = 0.2 * np.sin(3 * x_grid) * np.cos(2 * y_grid)
    elif soil_type == "Mountain Soil":
        # Rocky surface for mountain soil
        z_grid = 0.2 * (np.sin(5 * x_grid**2) + np.cos(5 * y_grid**2))
    else:
        # Default pattern
        z_grid = 0.1 * np.sin(5 * x_grid) + 0.1 * np.cos(5 * y_grid)

    # Create the 3D surface plot
    fig = go.Figure(data=[
        go.Surface(x=x_grid,
                   y=y_grid,
                   z=z_grid,
                   colorscale=[[0, color], [1, color]],
                   showscale=False,
                   opacity=0.9)
    ])

    # Add some particles to represent soil texture
    particle_count = 50

    # Create random positions for particles
    x_particles = np.random.uniform(-1, 1, particle_count)
    y_particles = np.random.uniform(-1, 1, particle_count)

    # Calculate z positions to be slightly above the surface
    z_particles = []
    for i in range(particle_count):
        # Find nearest grid point
        x_idx = np.argmin(np.abs(x - x_particles[i]))
        y_idx = np.argmin(np.abs(y - y_particles[i]))
        # Set particle slightly above surface
        z_particles.append(z_grid[y_idx, x_idx] + 0.05 +
                           0.05 * np.random.random())

    # Add scatter points for soil particles
    fig.add_trace(
        go.Scatter3d(x=x_particles,
                     y=y_particles,
                     z=z_particles,
                     mode='markers',
                     marker=dict(size=4, color=color, opacity=0.7),
                     hoverinfo="none"))

    # Customize the layout
    fig.update_layout(
        margin=dict(l=0, r=0, b=0, t=0),
        scene=dict(xaxis=dict(visible=False, showticklabels=False),
                   yaxis=dict(visible=False, showticklabels=False),
                   zaxis=dict(visible=False, showticklabels=False),
                   camera=dict(eye=dict(x=1.5, y=1.5, z=1.2),
                               up=dict(x=0, y=0, z=1)),
                   aspectmode='cube'),
        height=220,
        width=300,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )

    return fig


def soil_selector():
    """Component for selecting soil type with 3D visualization"""

    st.markdown(
        "<h1 style='text-align: center; animation: fadeIn 1.5s;'>Select Your Soil Type</h1>",
        unsafe_allow_html=True)

    # Add custom CSS for animations and styling
    st.markdown("""
    <style>
    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    
    @keyframes slideIn {
        0% { transform: translateY(20px); opacity: 0; }
        100% { transform: translateY(0); opacity: 1; }
    }
    
    @keyframes pulseGlow {
        0% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.5); }
        50% { box-shadow: 0 0 16px rgba(29, 185, 84, 0.8); }
        100% { box-shadow: 0 0 8px rgba(29, 185, 84, 0.5); }
    }
    
    .soil-card {
        animation: slideIn 0.5s ease-out;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border-radius: 10px;
        padding: 10px;
        background-color: #212121;
    }
    
    .soil-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 20px rgba(0,0,0,0.2);
    }
    
    .selected-card {
        animation: pulseGlow 2s infinite;
        border: 2px solid #1DB954;
    }
    
    .soil-title {
        color: #ffffff;
        font-weight: bold;
        text-align: center;
        margin-bottom: 10px;
    }
    
    .soil-button {
        background-color: #1DB954;
        color: white;
        border: none;
        border-radius: 20px;
        padding: 8px 16px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        transition: all 0.3s ease;
        width: 100%;
    }
    
    .soil-button:hover {
        background-color: #1ed760;
        transform: scale(1.05);
    }
    </style>
    """,
                unsafe_allow_html=True)

    # Get soil selection
    selected_soil = st.session_state.selected_soil

    # Create dynamic grid based on screen size - 3 columns for large screens, 2 for medium
    cols = st.columns([1, 1, 1])

    # Create clickable soil cards
    for i, soil in enumerate(soil_types):
        with cols[i % 3]:
            # Card container with conditional styling for selected card
            selected_class = "selected-card" if selected_soil == soil[
                "name"] else ""
            st.markdown(f"""
            <div class="soil-card {selected_class}" style="animation-delay: {i * 0.1}s">
                <h3 class="soil-title">{soil["name"]}</h3>
            </div>
            """,
                        unsafe_allow_html=True)

            # Try to load Lottie animation, fall back to 3D model if not available
            animation_url = SOIL_ANIMATIONS.get(soil["name"])
            animation_data = load_lottie_url(animation_url)

            if animation_data:
                st_lottie(animation_data,
                          height=150,
                          key=f"soil_animation_{i}")
            else:
                # Display 3D soil model as fallback
                fig = create_3d_soil_model(soil["name"])
                st.plotly_chart(fig, use_container_width=True)

            # Show soil details
            with st.expander("Soil Details"):
                st.write(soil["description"])

            # Selection button
            button_key = f"soil_button_{i}"
            if st.button("Select",
                         key=button_key,
                         use_container_width=True,
                         disabled=(selected_soil == soil["name"])):
                st.session_state.selected_soil = soil["name"]
                st.session_state.show_results = False
                st.rerun()

            # Show selected indicator with animation
            if selected_soil == soil["name"]:
                st.markdown("""
                <div style="background-color: #1DB954; color: white; padding: 10px; 
                border-radius: 5px; text-align: center; animation: pulseGlow 2s infinite;">
                ✅ Selected
                </div>
                """,
                            unsafe_allow_html=True)
