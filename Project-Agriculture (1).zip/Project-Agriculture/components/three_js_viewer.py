import streamlit as st
import streamlit.components.v1 as components

class ThreeJsViewer:
    """A component for rendering 3D models using Three.js"""
    
    def __init__(self):
        self.height = 400
        
    def display_farm_model(self):
        """Display a 3D farm model"""
        
        # Custom HTML/JS component using Three.js
        # We're building a simple 3D farm visualization
        three_js_code = """
        <div id="3d-farm" style="width:100%; height:400px; border-radius: 10px; overflow: hidden;"></div>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.min.js"></script>
        
        <script>
            // Initialize the scene
            const container = document.getElementById('3d-farm');
            const scene = new THREE.Scene();
            scene.background = new THREE.Color(0xAFD6B0);
            
            // Add a camera
            const camera = new THREE.PerspectiveCamera(75, container.clientWidth/container.clientHeight, 0.1, 1000);
            camera.position.set(10, 8, 10);
            
            // Add renderer
            const renderer = new THREE.WebGLRenderer({ antialias: true });
            renderer.setSize(container.clientWidth, container.clientHeight);
            container.appendChild(renderer.domElement);
            
            // Add orbit controls
            const controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.25;
            
            // Add lighting
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
            scene.add(ambientLight);
            
            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(5, 10, 7);
            scene.add(directionalLight);
            
            // Create a ground plane
            const groundGeometry = new THREE.PlaneGeometry(20, 20);
            const groundMaterial = new THREE.MeshStandardMaterial({ 
                color: 0x6B8E23, 
                side: THREE.DoubleSide 
            });
            const ground = new THREE.Mesh(groundGeometry, groundMaterial);
            ground.rotation.x = -Math.PI / 2;
            scene.add(ground);
            
            // Create farm elements
            
            // 1. Create field patches
            function createField(x, z, w, h, color) {
                const geometry = new THREE.PlaneGeometry(w, h);
                const material = new THREE.MeshStandardMaterial({ 
                    color: color, 
                    side: THREE.DoubleSide 
                });
                const field = new THREE.Mesh(geometry, material);
                field.rotation.x = -Math.PI / 2;
                field.position.set(x, 0.01, z);  // Slightly above ground to prevent z-fighting
                scene.add(field);
                return field;
            }
            
            // Create different field patches
            createField(-5, -5, 8, 8, 0x90EE90);  // Light green field
            createField(5, -5, 8, 8, 0xDAA520);   // Golden field (wheat)
            createField(-5, 5, 8, 8, 0x9ACD32);   // Yellow-green field
            createField(5, 5, 8, 8, 0xBDB76B);    // Dark khaki field
            
            // 2. Create trees
            function createTree(x, z) {
                // Tree trunk
                const trunkGeometry = new THREE.CylinderGeometry(0.2, 0.2, 1, 8);
                const trunkMaterial = new THREE.MeshStandardMaterial({ color: 0x8B4513 });
                const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
                trunk.position.set(x, 0.5, z);
                scene.add(trunk);
                
                // Tree foliage
                const foliageGeometry = new THREE.ConeGeometry(1, 2, 8);
                const foliageMaterial = new THREE.MeshStandardMaterial({ color: 0x228B22 });
                const foliage = new THREE.Mesh(foliageGeometry, foliageMaterial);
                foliage.position.set(x, 2, z);
                scene.add(foliage);
            }
            
            // Add trees around the perimeter
            createTree(-8, -8);
            createTree(-8, 8);
            createTree(8, -8);
            createTree(8, 8);
            
            // 3. Create a simple farmhouse
            function createFarmhouse(x, z) {
                // House base
                const baseGeometry = new THREE.BoxGeometry(3, 2, 3);
                const baseMaterial = new THREE.MeshStandardMaterial({ color: 0xE8BEAC });
                const base = new THREE.Mesh(baseGeometry, baseMaterial);
                base.position.set(x, 1, z);
                scene.add(base);
                
                // Roof
                const roofGeometry = new THREE.ConeGeometry(3, 1.5, 4);
                const roofMaterial = new THREE.MeshStandardMaterial({ color: 0xA52A2A });
                const roof = new THREE.Mesh(roofGeometry, roofMaterial);
                roof.position.set(x, 2.75, z);
                roof.rotation.y = Math.PI / 4;
                scene.add(roof);
            }
            
            // Add a farmhouse
            createFarmhouse(0, 0);
            
            // Add tractors or farm equipment (simplified)
            function createTractor(x, z) {
                // Tractor body
                const bodyGeometry = new THREE.BoxGeometry(1, 0.6, 0.8);
                const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0xFF0000 });
                const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
                body.position.set(x, 0.5, z);
                scene.add(body);
                
                // Wheels
                const wheelGeometry = new THREE.CylinderGeometry(0.3, 0.3, 0.2, 8);
                const wheelMaterial = new THREE.MeshStandardMaterial({ color: 0x000000 });
                
                const frontLeftWheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
                frontLeftWheel.rotation.z = Math.PI / 2;
                frontLeftWheel.position.set(x + 0.4, 0.3, z + 0.3);
                scene.add(frontLeftWheel);
                
                const frontRightWheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
                frontRightWheel.rotation.z = Math.PI / 2;
                frontRightWheel.position.set(x + 0.4, 0.3, z - 0.3);
                scene.add(frontRightWheel);
                
                const rearLeftWheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
                rearLeftWheel.rotation.z = Math.PI / 2;
                rearLeftWheel.position.set(x - 0.4, 0.3, z + 0.3);
                scene.add(rearLeftWheel);
                
                const rearRightWheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
                rearRightWheel.rotation.z = Math.PI / 2;
                rearRightWheel.position.set(x - 0.4, 0.3, z - 0.3);
                scene.add(rearRightWheel);
            }
            
            // Add a tractor
            createTractor(-3, 3);
            
            // Animation loop
            function animate() {
                requestAnimationFrame(animate);
                controls.update();
                renderer.render(scene, camera);
            }
            
            // Handle window resize
            window.addEventListener('resize', () => {
                camera.aspect = container.clientWidth / container.clientHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(container.clientWidth, container.clientHeight);
            });
            
            // Start animation
            animate();
        </script>
        """
        
        # Display the Three.js visualization
        components.html(three_js_code, height=self.height)
    
    def display_soil_model(self, soil_type):
        """Display a 3D soil model for a specific soil type"""
        
        # Calculate texture values based on soil type
        soil_textures = {
            "Alluvial Soil": {"sand": 0.4, "silt": 0.4, "clay": 0.2, "color": "#D2B48C"},
            "Black Soil": {"sand": 0.2, "silt": 0.3, "clay": 0.5, "color": "#32312E"},
            "Red Soil": {"sand": 0.5, "silt": 0.2, "clay": 0.3, "color": "#A52A2A"},
            "Laterite Soil": {"sand": 0.6, "silt": 0.2, "clay": 0.2, "color": "#FF4500"},
            "Desert Soil": {"sand": 0.9, "silt": 0.05, "clay": 0.05, "color": "#EDC9AF"},
            "Mountain Soil": {"sand": 0.4, "silt": 0.3, "clay": 0.3, "color": "#8B4513"}
        }
        
        # Get texture values for the selected soil, or use default values
        texture = soil_textures.get(soil_type, {"sand": 0.33, "silt": 0.33, "clay": 0.34, "color": "#A0522D"})
        
        # Three.js code for soil visualization
        three_js_code = f"""
        <div id="3d-soil" style="width:100%; height:300px; border-radius: 10px; overflow: hidden;"></div>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.min.js"></script>
        
        <script>
            // Initialize the scene
            const container = document.getElementById('3d-soil');
            const scene = new THREE.Scene();
            scene.background = new THREE.Color(0xF5F5F5);
            
            // Add a camera
            const camera = new THREE.PerspectiveCamera(75, container.clientWidth/container.clientHeight, 0.1, 1000);
            camera.position.set(0, 1, 2);
            
            // Add renderer
            const renderer = new THREE.WebGLRenderer({{ antialias: true }});
            renderer.setSize(container.clientWidth, container.clientHeight);
            container.appendChild(renderer.domElement);
            
            // Add orbit controls
            const controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.25;
            
            // Add lighting
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
            scene.add(ambientLight);
            
            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(1, 2, 1);
            scene.add(directionalLight);
            
            // Create soil visualization
            // Texture values from soil type
            const sandRatio = {texture['sand']};
            const siltRatio = {texture['silt']};
            const clayRatio = {texture['clay']};
            const soilColor = "{texture['color']}";
            
            // Create a soil container
            const soilGeometry = new THREE.CylinderGeometry(1, 1, 0.5, 32);
            const soilMaterial = new THREE.MeshStandardMaterial({{ 
                color: soilColor,
                roughness: 0.8, 
                metalness: 0.1
            }});
            const soil = new THREE.Mesh(soilGeometry, soilMaterial);
            soil.position.y = -0.25;
            scene.add(soil);
            
            // Create particles to represent soil composition
            function createParticles(count, size, color, yLevel, spreadFactor) {{
                const geometry = new THREE.SphereGeometry(size, 8, 8);
                const material = new THREE.MeshStandardMaterial({{ color: color }});
                
                const group = new THREE.Group();
                
                for (let i = 0; i < count; i++) {{
                    const particle = new THREE.Mesh(geometry, material);
                    // Random position within cylinder
                    const radius = Math.random() * 0.9;
                    const theta = Math.random() * Math.PI * 2;
                    particle.position.x = radius * Math.cos(theta);
                    particle.position.z = radius * Math.sin(theta);
                    particle.position.y = yLevel + (Math.random() * spreadFactor - spreadFactor/2);
                    
                    // Random rotation
                    particle.rotation.x = Math.random() * Math.PI;
                    particle.rotation.y = Math.random() * Math.PI;
                    particle.rotation.z = Math.random() * Math.PI;
                    
                    group.add(particle);
                }}
                
                return group;
            }}
            
            // Sand particles (larger, lighter color)
            const sandCount = Math.floor(sandRatio * 50);
            const sand = createParticles(sandCount, 0.03, 0xE6D2B5, 0, 0.4);
            scene.add(sand);
            
            // Silt particles (medium size, medium color)
            const siltCount = Math.floor(siltRatio * 70);
            const silt = createParticles(siltCount, 0.02, 0xC3A68A, 0, 0.4);
            scene.add(silt);
            
            // Clay particles (smaller, darker color)
            const clayCount = Math.floor(clayRatio * 100);
            const clay = createParticles(clayCount, 0.01, 0x8B7355, 0, 0.4);
            scene.add(clay);
            
            // Add small plants/roots to show fertility
            function createPlant() {{
                const rootGeometry = new THREE.CylinderGeometry(0.01, 0.01, 0.3, 8);
                const rootMaterial = new THREE.MeshStandardMaterial({{ color: 0x8B4513 }});
                const root = new THREE.Mesh(rootGeometry, rootMaterial);
                root.rotation.x = Math.PI / 4;
                root.position.y = 0.05;
                
                const leafGeometry = new THREE.ConeGeometry(0.05, 0.1, 8);
                const leafMaterial = new THREE.MeshStandardMaterial({{ color: 0x228B22 }});
                const leaf = new THREE.Mesh(leafGeometry, leafMaterial);
                leaf.position.y = 0.2;
                leaf.position.x = 0.02;
                
                const plant = new THREE.Group();
                plant.add(root);
                plant.add(leaf);
                
                // Position the plant on the soil surface
                const radius = Math.random() * 0.7;
                const theta = Math.random() * Math.PI * 2;
                plant.position.x = radius * Math.cos(theta);
                plant.position.z = radius * Math.sin(theta);
                
                return plant;
            }}
            
            // Add a few plants based on soil fertility
            // More fertile soils get more plants
            const plantCount = Math.floor((siltRatio * 0.7 + clayRatio * 0.3) * 10);
            for (let i = 0; i < plantCount; i++) {{
                const plant = createPlant();
                scene.add(plant);
            }}
            
            // Animation loop
            function animate() {{
                requestAnimationFrame(animate);
                controls.update();
                renderer.render(scene, camera);
            }}
            
            // Handle window resize
            window.addEventListener('resize', () => {{
                camera.aspect = container.clientWidth / container.clientHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(container.clientWidth, container.clientHeight);
            }});
            
            // Start animation
            animate();
        </script>
        """
        
        # Display the Three.js visualization
        components.html(three_js_code, height=300)
    
    def display_crop_model(self, crop_name):
        """Display a 3D model of the specified crop"""
        
        # Different crop configurations
        crop_configs = {
            "Rice": {
                "color": "#A1D39F",
                "height": 1.0,
                "stem_width": 0.01,
                "leaf_count": 8,
                "leaf_length": 0.3,
                "type": "grain"
            },
            "Wheat": {
                "color": "#EFD469",
                "height": 0.8,
                "stem_width": 0.01,
                "leaf_count": 6,
                "leaf_length": 0.2,
                "type": "grain"
            },
            "Cotton": {
                "color": "#F4F4F4",
                "height": 1.2,
                "stem_width": 0.015,
                "leaf_count": 10,
                "leaf_length": 0.15,
                "type": "fiber"
            },
            "Sugarcane": {
                "color": "#A1D39F",
                "height": 2.0,
                "stem_width": 0.02,
                "leaf_count": 12,
                "leaf_length": 0.4,
                "type": "cane"
            },
            "Maize": {
                "color": "#F9E076",
                "height": 1.8,
                "stem_width": 0.02,
                "leaf_count": 12,
                "leaf_length": 0.4,
                "type": "corn"
            }
        }
        
        # Get the configuration for the selected crop, or use default values
        config = crop_configs.get(crop_name, {
            "color": "#4CAF50",
            "height": 1.0,
            "stem_width": 0.01,
            "leaf_count": 8,
            "leaf_length": 0.25,
            "type": "generic"
        })
        
        # Three.js code for crop visualization
        three_js_code = f"""
        <div id="3d-crop-{crop_name.lower().replace(' ', '-')}" style="width:100%; height:250px; border-radius: 10px; overflow: hidden;"></div>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.min.js"></script>
        
        <script>
            // Initialize the scene
            const container = document.getElementById('3d-crop-{crop_name.lower().replace(' ', '-')}');
            const scene = new THREE.Scene();
            scene.background = new THREE.Color(0xF5F5F5);
            
            // Add a camera
            const camera = new THREE.PerspectiveCamera(75, container.clientWidth/container.clientHeight, 0.1, 1000);
            camera.position.set(0.5, 0.5, 1);
            
            // Add renderer
            const renderer = new THREE.WebGLRenderer({{ antialias: true }});
            renderer.setSize(container.clientWidth, container.clientHeight);
            container.appendChild(renderer.domElement);
            
            // Add orbit controls
            const controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.25;
            
            // Add lighting
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
            scene.add(ambientLight);
            
            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
            directionalLight.position.set(1, 2, 1);
            scene.add(directionalLight);
            
            // Create a small ground
            const groundGeometry = new THREE.CircleGeometry(0.3, 32);
            const groundMaterial = new THREE.MeshStandardMaterial({{ 
                color: 0x8B4513,
                roughness: 1.0
            }});
            const ground = new THREE.Mesh(groundGeometry, groundMaterial);
            ground.rotation.x = -Math.PI / 2;
            ground.position.y = -0.2;
            scene.add(ground);
            
            // Create the crop model based on type
            const cropType = "{config['type']}";
            const cropColor = "{config['color']}";
            const stemHeight = {config['height']};
            const stemWidth = {config['stem_width']};
            const leafCount = {config['leaf_count']};
            const leafLength = {config['leaf_length']};
            
            // Create crop model
            function createCrop() {{
                const cropGroup = new THREE.Group();
                
                // Common elements - stem
                const stemGeometry = new THREE.CylinderGeometry(stemWidth, stemWidth * 1.2, stemHeight, 8);
                const stemMaterial = new THREE.MeshStandardMaterial({{ color: 0x228B22 }});
                const stem = new THREE.Mesh(stemGeometry, stemMaterial);
                stem.position.y = stemHeight / 2 - 0.2;
                cropGroup.add(stem);
                
                // Add leaves along the stem
                for (let i = 0; i < leafCount; i++) {{
                    const leafGeometry = new THREE.PlaneGeometry(leafLength, leafLength / 4);
                    const leafMaterial = new THREE.MeshStandardMaterial({{ 
                        color: 0x4CAF50,
                        side: THREE.DoubleSide
                    }});
                    const leaf = new THREE.Mesh(leafGeometry, leafMaterial);
                    
                    // Position leaves spirally around stem
                    const angle = (i / leafCount) * Math.PI * 4;
                    const heightRatio = i / leafCount;
                    leaf.position.y = (heightRatio * stemHeight * 0.8) - 0.1;
                    leaf.position.x = Math.sin(angle) * (stemWidth * 10);
                    leaf.position.z = Math.cos(angle) * (stemWidth * 10);
                    
                    // Rotate leaf to point outward
                    leaf.lookAt(new THREE.Vector3(
                        leaf.position.x * 2,
                        leaf.position.y, 
                        leaf.position.z * 2
                    ));
                    
                    cropGroup.add(leaf);
                }}
                
                // Add type-specific elements at the top
                if (cropType === "grain") {{
                    // Create a grain head (wheat, rice, etc.)
                    const grainGeometry = new THREE.CylinderGeometry(stemWidth * 3, stemWidth * 1.5, stemHeight * 0.2, 8);
                    const grainMaterial = new THREE.MeshStandardMaterial({{ color: cropColor }});
                    const grain = new THREE.Mesh(grainGeometry, grainMaterial);
                    grain.position.y = stemHeight - 0.1;
                    cropGroup.add(grain);
                }} else if (cropType === "fiber") {{
                    // Create cotton bolls
                    const bollGeometry = new THREE.SphereGeometry(stemWidth * 5, 8, 8);
                    const bollMaterial = new THREE.MeshStandardMaterial({{ color: cropColor }});
                    
                    // Add a few bolls
                    const bollCount = Math.floor(1 + Math.random() * 3);
                    for (let i = 0; i < bollCount; i++) {{
                        const boll = new THREE.Mesh(bollGeometry, bollMaterial);
                        const bollAngle = i * Math.PI / 2;
                        const bollHeight = stemHeight * (0.6 + 0.4 * Math.random());
                        boll.position.set(
                            Math.sin(bollAngle) * (stemWidth * 15),
                            bollHeight - 0.2,
                            Math.cos(bollAngle) * (stemWidth * 15)
                        );
                        cropGroup.add(boll);
                    }}
                }} else if (cropType === "corn") {{
                    // Create corn ears
                    const cobGeometry = new THREE.CylinderGeometry(0.03, 0.03, 0.15, 8);
                    const cobMaterial = new THREE.MeshStandardMaterial({{ 
                        color: cropColor
                    }});
                    const cob = new THREE.Mesh(cobGeometry, cobMaterial);
                    cob.rotation.z = Math.PI / 2;
                    cob.position.y = stemHeight / 2;
                    cob.position.x = stemWidth * 10;
                    cropGroup.add(cob);
                    
                    // Add corn husk
                    const huskGeometry = new THREE.PlaneGeometry(0.2, 0.1);
                    const huskMaterial = new THREE.MeshStandardMaterial({{ 
                        color: 0x90EE90,
                        side: THREE.DoubleSide
                    }});
                    const husk = new THREE.Mesh(huskGeometry, huskMaterial);
                    husk.position.x = cob.position.x;
                    husk.position.y = cob.position.y;
                    husk.rotation.z = Math.PI / 2;
                    cropGroup.add(husk);
                }}
                
                return cropGroup;
            }}
            
            // Create a small field of crops
            const cropCount = 5;
            for (let i = 0; i < cropCount; i++) {{
                    const crop = createCrop();
                    const angle = (i / cropCount) * Math.PI * 2;
                    const radius = 0.15;
                    const offset = i * 0.02;
                    crop.position.x = Math.sin(angle) * radius;
                    crop.position.z = Math.cos(angle) * radius;
                    crop.scale.set(0.5, 0.5, 0.5);
                    scene.add(crop);
            }}
            
            // Animation loop
            function animate() {{
                requestAnimationFrame(animate);
                controls.update();
                renderer.render(scene, camera);
            }}
            
            // Handle window resize
            window.addEventListener('resize', () => {{
                camera.aspect = container.clientWidth / container.clientHeight;
                camera.updateProjectionMatrix();
                renderer.setSize(container.clientWidth, container.clientHeight);
            }});
            
            // Start animation
            animate();
        </script>
        """
        
        # Display the Three.js visualization
        components.html(three_js_code, height=250)