"""
Crop data and recommendation engine for the agricultural recommendation platform
"""

def get_recommended_crops(soil_type, season):
    """
    Returns recommended crops based on soil type and season
    
    Parameters:
    soil_type (str): Type of soil (e.g., "Alluvial Soil", "Black Soil")
    season (str): Growing season (e.g., "Kharif", "Rabi", "Summer")
    
    Returns:
    list: List of recommended crop objects with their details
    """
    
    
    crop_database = {
        "Alluvial Soil": {
            "Kharif": [
                {
                    "name": "Rice",
                    "suitability": 9,
                    "water_req": "High",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Prepare land properly with good leveling for water management. Transplant seedlings at proper spacing. Maintain adequate water levels throughout the growing period."
                },
                {
                    "name": "Maize",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "80-110 days",
                    "economic_value": "Medium",
                    "growing_tips": "Plant seeds at proper depth (3-5 cm) and spacing. Ensure adequate drainage. Apply nitrogen fertilizer in split doses for better yields."
                },
                {
                    "name": "Cotton",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "150-180 days",
                    "economic_value": "High",
                    "growing_tips": "Proper seed treatment is essential. Maintain optimum plant population. Practice integrated pest management for bollworms and other pests."
                },
                {
                    "name": "Sugarcane",
                    "suitability": 8,
                    "water_req": "High",
                    "growth_period": "12-18 months",
                    "economic_value": "High",
                    "growing_tips": "Use healthy, disease-free setts for planting. Provide adequate irrigation during critical growth stages. Earthing up is important to prevent lodging."
                }
            ],
            "Rabi": [
                {
                    "name": "Wheat",
                    "suitability": 9,
                    "water_req": "Medium",
                    "growth_period": "100-120 days",
                    "economic_value": "High",
                    "growing_tips": "Sow at optimum time (early November). Provide irrigation at critical stages (crown root initiation, flowering, and grain filling)."
                },
                {
                    "name": "Mustard",
                    "suitability": 7,
                    "water_req": "Low to Medium",
                    "growth_period": "110-140 days",
                    "economic_value": "Medium",
                    "growing_tips": "Prepare a fine seed bed. Apply sulfur for better oil content. Maintain bee population for better pollination."
                },
                {
                    "name": "Potato",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "90-120 days",
                    "economic_value": "High",
                    "growing_tips": "Use certified, disease-free seed tubers. Plant at proper depth and spacing. Earthing up is essential to prevent greening of tubers."
                }
            ],
            "Summer": [
                {
                    "name": "Moong (Green Gram)",
                    "suitability": 8,
                    "water_req": "Low to Medium",
                    "growth_period": "60-90 days",
                    "economic_value": "Medium",
                    "growing_tips": "Good for short-duration cropping. Needs limited irrigation. Apply Rhizobium culture for better nitrogen fixation."
                },
                {
                    "name": "Watermelon",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "80-110 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Provide support for climbing varieties. Ensure good pollination. Maintain soil moisture for proper fruit development."
                }
            ]
        },
        "Black Soil": {
            "Kharif": [
                {
                    "name": "Cotton",
                    "suitability": 9,
                    "water_req": "Medium",
                    "growth_period": "150-180 days",
                    "economic_value": "High",
                    "growing_tips": "Black soil is excellent for cotton cultivation. Practice proper spacing and implement pest management strategies for bollworms."
                },
                {
                    "name": "Soybean",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Seed treatment with Rhizobium is beneficial. Ensure proper drainage as black soil can get waterlogged."
                },
                {
                    "name": "Pigeon Pea (Arhar)",
                    "suitability": 8,
                    "water_req": "Low to Medium",
                    "growth_period": "150-270 days",
                    "economic_value": "Medium",
                    "growing_tips": "Deep ploughing is beneficial. Plant at recommended spacing. Intercropping with shorter duration crops can be done."
                }
            ],
            "Rabi": [
                {
                    "name": "Wheat",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "100-120 days",
                    "economic_value": "High",
                    "growing_tips": "Line sowing is recommended. Apply balanced fertilizers. Irrigate at critical growth stages."
                },
                {
                    "name": "Chickpea (Gram)",
                    "suitability": 9,
                    "water_req": "Low",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium",
                    "growing_tips": "Thrives well in residual moisture of black soils. Apply phosphorus fertilizer for better nodulation and yield."
                },
                {
                    "name": "Safflower",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "110-140 days",
                    "economic_value": "Medium",
                    "growing_tips": "Drought resistant crop suitable for black soils. Control aphids during flowering stage."
                }
            ],
            "Summer": [
                {
                    "name": "Sesame",
                    "suitability": 7,
                    "water_req": "Low",
                    "growth_period": "80-100 days",
                    "economic_value": "Medium",
                    "growing_tips": "Prepare fine seed bed. Thin seedlings after establishment. Harvest at proper maturity to avoid shattering."
                },
                {
                    "name": "Sunflower",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "90-110 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Deep ploughing is beneficial. Keep beehives for better pollination. Apply boron if deficiency symptoms appear."
                }
            ]
        },
        "Red Soil": {
            "Kharif": [
                {
                    "name": "Groundnut",
                    "suitability": 9,
                    "water_req": "Medium",
                    "growth_period": "100-130 days",
                    "economic_value": "High",
                    "growing_tips": "Well-drained red soils are ideal for groundnut. Apply gypsum at flowering stage for better pod development."
                },
                {
                    "name": "Millets (Jowar/Bajra)",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "90-120 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Drought resistant crops suitable for red soils. Use improved varieties for better yields."
                },
                {
                    "name": "Castor",
                    "suitability": 7,
                    "water_req": "Low",
                    "growth_period": "140-170 days",
                    "economic_value": "Medium",
                    "growing_tips": "Deep ploughing helps in better root establishment. Adopt proper spacing. Apply nitrogen in split doses."
                }
            ],
            "Rabi": [
                {
                    "name": "Mustard",
                    "suitability": 7,
                    "water_req": "Low to Medium",
                    "growth_period": "110-140 days",
                    "economic_value": "Medium",
                    "growing_tips": "Use improved varieties. Apply sulfur for better oil content. Irrigate at critical stages."
                },
                {
                    "name": "Horsegram",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "100-120 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Drought resistant crop suitable for poor red soils. Requires minimal inputs."
                }
            ],
            "Summer": [
                {
                    "name": "Sesame",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "80-100 days",
                    "economic_value": "Medium",
                    "growing_tips": "Prepare land thoroughly. Thin plants at early stage. Harvest at proper maturity."
                },
                {
                    "name": "Green Gram (Moong)",
                    "suitability": 7,
                    "water_req": "Low to Medium",
                    "growth_period": "60-90 days",
                    "economic_value": "Medium",
                    "growing_tips": "Short duration crop suitable for summer. Apply Rhizobium culture for better nodulation."
                }
            ]
        },
        "Laterite Soil": {
            "Kharif": [
                {
                    "name": "Rice",
                    "suitability": 7,
                    "water_req": "High",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Apply lime to reduce acidity. Use acid-tolerant varieties. Apply micronutrients, especially zinc."
                },
                {
                    "name": "Finger Millet (Ragi)",
                    "suitability": 9,
                    "water_req": "Low to Medium",
                    "growth_period": "90-120 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Well adapted to laterite soils. Apply organic matter to improve soil structure. Transplanting gives better yields."
                },
                {
                    "name": "Pineapple",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "18-24 months",
                    "economic_value": "High",
                    "growing_tips": "Plant on raised beds to ensure drainage. Apply potassium for better fruit quality. Mulching is beneficial."
                }
            ],
            "Rabi": [
                {
                    "name": "Sweet Potato",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium",
                    "growing_tips": "Plant on ridges or mounds. Use vine cuttings for planting. Proper weeding is important."
                },
                {
                    "name": "Pulses (Black Gram)",
                    "suitability": 7,
                    "water_req": "Low",
                    "growth_period": "90-110 days",
                    "economic_value": "Medium",
                    "growing_tips": "Apply lime before planting. Seed treatment with Rhizobium is beneficial. Needs good drainage."
                }
            ],
            "Summer": [
                {
                    "name": "Turmeric",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "8-9 months",
                    "economic_value": "High",
                    "growing_tips": "Plant on raised beds. Apply adequate organic matter. Mulching helps in moisture conservation."
                },
                {
                    "name": "Ginger",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "8-9 months",
                    "economic_value": "High",
                    "growing_tips": "Requires partially shaded conditions. Plant disease-free rhizomes. Apply organic mulch."
                }
            ]
        },
        "Desert Soil": {
            "Kharif": [
                {
                    "name": "Pearl Millet (Bajra)",
                    "suitability": 9,
                    "water_req": "Low",
                    "growth_period": "80-110 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Highly drought resistant. Use improved hybrid varieties. Early sowing with onset of rains is beneficial."
                },
                {
                    "name": "Cluster Bean (Guar)",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium",
                    "growing_tips": "Drought tolerant crop. Seed treatment with Rhizobium is beneficial. Limited irrigation increases yield."
                },
                {
                    "name": "Moth Bean",
                    "suitability": 7,
                    "water_req": "Very Low",
                    "growth_period": "75-90 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Extremely drought resistant. Suitable for very poor soils. Can be grown as intercrop."
                }
            ],
            "Rabi": [
                {
                    "name": "Mustard",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "110-140 days",
                    "economic_value": "Medium",
                    "growing_tips": "Tolerates drought conditions. Apply sulfur for better oil content. Limited irrigation at critical stages."
                },
                {
                    "name": "Cumin",
                    "suitability": 9,
                    "water_req": "Low",
                    "growth_period": "100-120 days",
                    "economic_value": "High",
                    "growing_tips": "Prepare fine seed bed. Light irrigation at regular intervals. Harvest at proper maturity."
                },
                {
                    "name": "Chickpea (Gram)",
                    "suitability": 7,
                    "water_req": "Low",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium",
                    "growing_tips": "Can be grown on residual moisture. Apply phosphorus fertilizer. Minimal irrigation required."
                }
            ],
            "Summer": [
                {
                    "name": "Watermelon",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "80-110 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Plant on ridges or mounds. Mulching helps in moisture conservation. Drip irrigation is beneficial."
                },
                {
                    "name": "Sesame",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "80-100 days",
                    "economic_value": "Medium",
                    "growing_tips": "Tolerates drought conditions. Thin seedlings after establishment. Limited irrigation increases yield."
                }
            ]
        },
        "Mountain Soil": {
            "Kharif": [
                {
                    "name": "Maize",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "80-110 days",
                    "economic_value": "Medium",
                    "growing_tips": "Use contour planting to prevent erosion. Apply organic matter. Use high-yielding varieties."
                },
                {
                    "name": "Rice (Upland)",
                    "suitability": 7,
                    "water_req": "Medium to High",
                    "growth_period": "90-120 days",
                    "economic_value": "Medium",
                    "growing_tips": "Terrace farming is ideal. Use adapted varieties for hilly regions. Apply balanced fertilizers."
                },
                {
                    "name": "Finger Millet (Ragi)",
                    "suitability": 9,
                    "water_req": "Low to Medium",
                    "growth_period": "90-120 days",
                    "economic_value": "Low to Medium",
                    "growing_tips": "Well adapted to mountain soils. Can be grown on slopes with contour planting. Apply organic manure."
                }
            ],
            "Rabi": [
                {
                    "name": "Wheat",
                    "suitability": 7,
                    "water_req": "Medium",
                    "growth_period": "100-120 days",
                    "economic_value": "High",
                    "growing_tips": "Plant after maize harvest. Use varieties adapted for hills. Apply balanced fertilizers."
                },
                {
                    "name": "Barley",
                    "suitability": 8,
                    "water_req": "Low to Medium",
                    "growth_period": "90-110 days",
                    "economic_value": "Medium",
                    "growing_tips": "More cold hardy than wheat. Can be grown at higher elevations. Requires less inputs."
                },
                {
                    "name": "Buckwheat",
                    "suitability": 8,
                    "water_req": "Low",
                    "growth_period": "75-90 days",
                    "economic_value": "Medium",
                    "growing_tips": "Short duration crop. Can be grown at high altitudes. Beneficial as bee forage crop."
                }
            ],
            "Summer": [
                {
                    "name": "French Beans",
                    "suitability": 8,
                    "water_req": "Medium",
                    "growth_period": "60-90 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Perform well in cooler mountain summers. Use bush varieties on slopes. Provide support for pole varieties."
                },
                {
                    "name": "Peas",
                    "suitability": 9,
                    "water_req": "Medium",
                    "growth_period": "60-90 days",
                    "economic_value": "Medium to High",
                    "growing_tips": "Ideal for higher elevations in summer. Seed treatment with Rhizobium is beneficial. Provide support for climbing varieties."
                }
            ]
        }
    }
    
    
    if soil_type in crop_database and season in crop_database[soil_type]:
        return crop_database[soil_type][season]
    else:
        return []
