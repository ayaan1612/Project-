"""
Season data for the agricultural recommendation platform
"""

# Database of seasons with detailed information
seasons = [
    {
        "name": "Kharif",
        "months": "June to October",
        "description": "The Kharif season coincides with the Southwest monsoon, with crops being sown at the beginning of the monsoon and harvested after the monsoon ends. It requires warm, wet weather for seed germination and crop growth."
    },
    {
        "name": "Rabi",
        "months": "November to April",
        "description": "The Rabi season starts after the Kharif season and continues through winter. Crops are sown at the beginning of winter and harvested in spring. Rabi crops require cool climate during growth and warm climate during maturation."
    },
    {
        "name": "Summer",
        "months": "March to June",
        "description": "The Summer or Zaid season falls between Rabi and Kharif seasons. Crops grown during this period require warm dry weather for growth and maturity and longer day length for flowering. Irrigation is essential as this is a dry period."
    }
]

def get_season_info(season_name):
    """
    Returns detailed information about a specific growing season
    
    Parameters:
    season_name (str): Name of the season (Kharif, Rabi, or Summer)
    
    Returns:
    dict: Detailed information about the season
    """
    
    # Detailed season information for education and visualization
    season_details = {
        "Kharif": {
            "description": "The Kharif season coincides with the Southwest monsoon. Crops are sown at the beginning of the monsoon (June-July) and harvested after the monsoon ends (October-November). This season is characterized by high temperatures and heavy rainfall.",
            "rainfall_pattern": "Heavy rainfall from monsoon, typically 750-1500 mm",
            "temperature_range": "25°C to 35°C (77°F to 95°F)",
            "humidity_range": "70% to 90%",
            "daylight_hours": "12 to 13 hours",
            "main_crops": ["Rice", "Maize", "Sorghum", "Pearl Millet", "Groundnut", "Soybean", "Cotton", "Sugarcane"],
            "farming_activities": [
                "Soil preparation before monsoon arrives",
                "Sowing with the onset of monsoon",
                "Weed management due to heavy rains",
                "Pest management, especially during humid periods",
                "Drainage management in heavy rainfall areas",
                "Harvesting after monsoon retreat"
            ],
            "challenges": [
                "Unpredictable monsoon patterns",
                "Excess rainfall and flooding",
                "High pest and disease pressure due to humidity",
                "Drainage issues in low-lying areas",
                "Post-harvest management during humid conditions"
            ],
            "tips": [
                "Select varieties according to rainfall patterns of your region",
                "Implement proper drainage systems before monsoon",
                "Have contingency crops ready in case of monsoon failure",
                "Monitor pest populations regularly",
                "Consider crop insurance due to monsoon uncertainties"
            ]
        },
        "Rabi": {
            "description": "The Rabi season starts after the Kharif season and continues through winter. Crops are sown at the beginning of winter (November-December) and harvested in spring (April-May). This season is characterized by cool temperatures during early growth and warmer temperatures during maturation.",
            "rainfall_pattern": "Moderate to light rainfall, typically 100-400 mm, some regions depend on winter precipitation",
            "temperature_range": "15°C to 25°C (59°F to 77°F), can drop below 10°C in northern regions",
            "humidity_range": "40% to 70%",
            "daylight_hours": "10 to 11 hours, increasing towards harvest time",
            "main_crops": ["Wheat", "Barley", "Mustard", "Peas", "Chickpea", "Linseed", "Coriander", "Cumin"],
            "farming_activities": [
                "Soil preparation after Kharif harvest",
                "Sowing as temperatures cool down",
                "Irrigation management (crucial due to less rainfall)",
                "Frost protection in northern regions",
                "Weed management during early crop growth",
                "Harvesting as temperatures rise in spring"
            ],
            "challenges": [
                "Cold stress in northern regions",
                "Irrigation dependency due to low rainfall",
                "Terminal heat stress during grain filling in late-sown crops",
                "Frost damage in sensitive crops",
                "Aphid and other cool-season pests"
            ],
            "tips": [
                "Complete sowing within the optimum window",
                "Schedule irrigation at critical crop growth stages",
                "Watch for frost forecasts and protect sensitive crops",
                "Monitor for aphids and rust diseases regularly",
                "Consider zero tillage to conserve moisture and reduce costs"
            ]
        },
        "Summer": {
            "description": "The Summer or Zaid season falls between Rabi and Kharif seasons. Crops are sown in March-April and harvested by June-July. This is characterized by high temperatures and longer day lengths. Irrigation is essential as this is typically a dry period in most parts of India.",
            "rainfall_pattern": "Very low rainfall, typically 0-100 mm, except pre-monsoon showers in some regions",
            "temperature_range": "32°C to 43°C (90°F to 110°F)",
            "humidity_range": "20% to 50%",
            "daylight_hours": "13 to 14 hours",
            "main_crops": ["Watermelon", "Muskmelon", "Cucumber", "Vegetables", "Moong Bean", "Urad Bean", "Fodder crops"],
            "farming_activities": [
                "Soil preparation after Rabi harvest",
                "Early sowing to utilize residual moisture",
                "Frequent irrigation",
                "Heat stress management",
                "Mulching to conserve soil moisture",
                "Quick harvesting and marketing"
            ],
            "challenges": [
                "Extreme heat stress",
                "High water requirement",
                "High evapotranspiration losses",
                "Higher irrigation costs",
                "Heat-loving pests and diseases",
                "Shorter growing window before monsoon"
            ],
            "tips": [
                "Choose short-duration, heat-tolerant varieties",
                "Use micro-irrigation systems for water efficiency",
                "Apply mulch to conserve soil moisture",
                "Irrigate during cooler parts of the day",
                "Consider shade nets for sensitive vegetable crops",
                "Plan marketing before monsoon arrival"
            ]
        }
    }
    
    # Return detailed information for the requested season
    return season_details.get(season_name, {"description": "Information not available for this season."})
