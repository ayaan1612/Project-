"""
Soil data and information for the agricultural recommendation platform
"""

# Database of soil types with detailed information
soil_types = [
    {
        "name": "Alluvial Soil",
        "description": "These soils are formed by river deposits and are among the most fertile soils in India. They are rich in potash, phosphoric acid, and lime, but poor in nitrogen. Found mainly in the northern plains and river valleys.",
        "regions": ["Indo-Gangetic Plains", "Brahmaputra Valley", "Coastal regions"],
        "suitable_crops": ["Rice", "Wheat", "Sugarcane", "Cotton", "Jute", "Maize", "Pulses"]
    },
    {
        "name": "Black Soil",
        "description": "Also known as Regur or Cotton soil, these are made up of volcanic rocks and lava flow. They are rich in calcium carbonate, magnesium, potash, and lime, but poor in phosphorus. They have high water retention capacity.",
        "regions": ["Deccan Plateau", "Maharashtra", "Gujarat", "Madhya Pradesh"],
        "suitable_crops": ["Cotton", "Sugarcane", "Tobacco", "Oilseeds", "Cereals", "Citrus fruits"]
    },
    {
        "name": "Red Soil",
        "description": "These soils develop on crystalline igneous rocks and are reddish in color due to iron oxide content. They are generally deficient in nitrogen, phosphorus, and organic matter. They are well-drained and suitable for drought-resistant crops.",
        "regions": ["Tamil Nadu", "Karnataka", "Andhra Pradesh", "Eastern parts of Rajasthan"],
        "suitable_crops": ["Millets", "Pulses", "Tobacco", "Groundnut", "Potato", "Fruits"]
    },
    {
        "name": "Laterite Soil",
        "description": "These soils are formed in areas with high temperature and heavy rainfall. They are rich in iron and aluminum, but poor in nitrogen, potash, lime, and organic matter. They are leached soils and generally acidic.",
        "regions": ["Western Ghats", "Eastern Ghats", "Orissa", "Assam", "Kerala"],
        "suitable_crops": ["Tea", "Coffee", "Rubber", "Coconut", "Areca nut", "Rice", "Millets"]
    },
    {
        "name": "Desert Soil",
        "description": "Found in arid regions, these soils are sandy with low organic matter. They contain high salt concentration in some areas. Irrigation improves their fertility, but water scarcity is a major challenge.",
        "regions": ["Rajasthan", "Parts of Punjab", "Haryana", "Gujarat"],
        "suitable_crops": ["Bajra", "Jowar", "Pulses", "Guar", "Cumin", "Castor", "Date Palm"]
    },
    {
        "name": "Mountain Soil",
        "description": "These soils are found in mountainous regions and are formed due to the accumulation of organic matter derived from forest growth. They are generally shallow, stony, and have coarse texture.",
        "regions": ["Himalayan Region", "Western and Eastern Ghats", "Nilgiri Hills"],
        "suitable_crops": ["Tea", "Coffee", "Spices", "Fruits", "Potatoes", "Barley", "Maize"]
    }
]

def get_soil_info(soil_type):
    """
    Returns detailed information about a specific soil type
    
    Parameters:
    soil_type (str): Name of the soil type
    
    Returns:
    dict: Detailed information about the soil
    """
    
    # Detailed soil information with additional data for visualization and education
    soil_details = {
        "Alluvial Soil": {
            "description": "Alluvial soils are among the most fertile soils in India. They are formed by sediments deposited by rivers. These soils are rich in minerals and nutrients, making them highly productive for agriculture.",
            "composition": {
                "Sand": 40,
                "Silt": 40,
                "Clay": 20
            },
            "properties": {
                "ph": "6.5-7.5 (Neutral to Slightly Alkaline)",
                "organic_matter": "Medium",
                "water_retention": "Good",
                "nutrient_content": "High"
            },
            "cultivation_practices": """
            Alluvial soils are highly suitable for a wide range of crops. Due to their good fertility and water retention, they respond well to irrigation and fertilizers. These soils are easy to till and have good workability throughout the year.
            """,
            "soil_preparation": """
            1. Deep ploughing is beneficial to improve soil aeration
            2. Ensure proper leveling, especially for crops like rice
            3. Apply organic matter to improve soil structure and fertility
            4. Prepare raised beds for vegetable crops during rainy season
            """,
            "water_management": """
            Alluvial soils have good water holding capacity but proper irrigation scheduling is still important:
            
            - Avoid over-irrigation which can lead to nutrient leaching
            - Implement crop-specific irrigation schedules
            - Consider drip irrigation for row crops to improve water use efficiency
            - Maintain proper drainage, especially in low-lying areas
            """,
            "fertilizer_recommendations": """
            Alluvial soils respond well to fertilizers:
            
            - Apply balanced NPK fertilizers based on soil tests
            - Split application of nitrogen is recommended
            - Apply organic manures to improve soil structure and microbial activity
            - Watch for micronutrient deficiencies, particularly zinc and iron
            """,
            "common_issues": """
            - Waterlogging in low-lying areas
            - Soil compaction due to intensive cultivation
            - Gradual depletion of organic matter
            - Micronutrient deficiencies may occur over time
            """
        },
        "Black Soil": {
            "description": "Black soils, also known as Regur or Cotton soils, are derived from volcanic rocks and lava flows. They have high clay content and retain moisture for a long time. These soils expand when wet and develop cracks when dry, which helps in soil aeration.",
            "composition": {
                "Sand": 20,
                "Silt": 30,
                "Clay": 50
            },
            "properties": {
                "ph": "7.5-8.5 (Alkaline)",
                "organic_matter": "Medium to High",
                "water_retention": "Very High",
                "nutrient_content": "High (except phosphorus)"
            },
            "cultivation_practices": """
            Black soils are highly suitable for growing cotton, hence also called 'cotton soils'. They require careful water management as they become sticky when wet and develop cracks when dry. These soils are self-ploughing due to their shrinking and swelling nature.
            """,
            "soil_preparation": """
            1. Timing of ploughing is critical - neither too wet nor too dry
            2. Deep ploughing once in 3-4 years helps in improving soil structure
            3. Prepare the land well before the onset of monsoon
            4. Maintain proper slope for drainage
            """,
            "water_management": """
            Water management is crucial in black soils:
            
            - Ensure proper drainage to prevent waterlogging
            - Implement contour bunding for soil and water conservation
            - Proper land leveling is essential
            - Practice furrow irrigation for row crops
            """,
            "fertilizer_recommendations": """
            Black soils are rich in nutrients but have some specific requirements:
            
            - Phosphorus application is essential as these soils fix phosphorus
            - Apply organic matter to improve soil structure
            - Gypsum application helps in reclaiming sodic black soils
            - Micronutrients like zinc should be applied based on soil tests
            """,
            "common_issues": """
            - Poor workability when too wet or too dry
            - Drainage problems during heavy rainfall
            - Phosphorus fixation
            - Soil cracking during dry periods
            - Iron deficiency in some crops
            """
        },
        "Red Soil": {
            "description": "Red soils derive their color from iron oxides. They are formed from the weathering of ancient crystalline and metamorphic rocks. These soils are generally light textured, porous, and have low water holding capacity.",
            "composition": {
                "Sand": 60,
                "Silt": 10,
                "Clay": 30
            },
            "properties": {
                "ph": "5.5-6.5 (Acidic to Neutral)",
                "organic_matter": "Low",
                "water_retention": "Low to Medium",
                "nutrient_content": "Low to Medium"
            },
            "cultivation_practices": """
            Red soils are suitable for drought-resistant crops due to their low water retention capacity. Proper nutrient management and organic matter addition are essential for improving soil fertility and productivity.
            """,
            "soil_preparation": """
            1. Add organic matter to improve water retention and fertility
            2. Practice contour cultivation on slopes to prevent erosion
            3. Incorporate crop residues into the soil
            4. Consider deep ploughing to break hardpans if present
            """,
            "water_management": """
            Water conservation is critical in red soils:
            
            - Implement water harvesting structures
            - Use mulching to reduce evaporation losses
            - Consider drip irrigation for efficient water use
            - Practice frequent but small irrigations
            """,
            "fertilizer_recommendations": """
            Red soils generally need comprehensive nutrient management:
            
            - Apply lime to correct soil acidity where needed
            - Use balanced NPK fertilizers based on soil tests
            - Organic manure application is highly beneficial
            - Consider micronutrient application, especially zinc, boron and sulphur
            """,
            "common_issues": """
            - Soil erosion, especially on slopes
            - Low water holding capacity
            - Multiple nutrient deficiencies
            - Soil acidity in high rainfall areas
            - Hardpan formation in some regions
            """
        },
        "Laterite Soil": {
            "description": "Laterite soils are formed under conditions of high temperature and heavy rainfall with alternate wet and dry periods. These soils undergo intense leaching, which removes silica and leaves behind oxides of iron and aluminum, giving the soil a red or reddish-brown color.",
            "composition": {
                "Sand": 45,
                "Silt": 15,
                "Clay": 40
            },
            "properties": {
                "ph": "4.5-5.5 (Strongly Acidic)",
                "organic_matter": "Low",
                "water_retention": "Low",
                "nutrient_content": "Low (leached)"
            },
            "cultivation_practices": """
            Laterite soils require significant management to improve their productivity. They are suitable for specific crops that can tolerate acidity and low nutrient status. Application of lime, organic matter, and balanced fertilizers is essential.
            """,
            "soil_preparation": """
            1. Apply lime 2-3 months before planting to reduce acidity
            2. Add organic matter to improve soil structure and fertility
            3. Create raised beds or mounds for better drainage
            4. Incorporate green manures whenever possible
            """,
            "water_management": """
            Managing water effectively is important:
            
            - Create proper drainage systems, especially in lowlands
            - Install soil and water conservation structures
            - Practice mulching to reduce evaporation
            - Consider water harvesting for dry season irrigation
            """,
            "fertilizer_recommendations": """
            Laterite soils need careful nutrient management:
            
            - Apply lime based on soil pH (typically 2-4 tons/ha)
            - Use acid-tolerant crop varieties when possible
            - Apply split doses of nitrogen fertilizers
            - Add organic manures to improve soil quality
            - Apply micronutrients, particularly zinc and boron
            """,
            "common_issues": """
            - Strong soil acidity
            - Phosphorus fixation by iron and aluminum oxides
            - Multiple nutrient deficiencies
            - Poor soil structure
            - Aluminum toxicity in very acidic conditions
            """
        },
        "Desert Soil": {
            "description": "Desert soils are found in arid regions with low rainfall. They are sandy in texture, have low organic matter, and often contain high concentrations of soluble salts. These soils are prone to wind erosion and have low water holding capacity.",
            "composition": {
                "Sand": 85,
                "Silt": 10,
                "Clay": 5
            },
            "properties": {
                "ph": "8.0-8.5 (Alkaline)",
                "organic_matter": "Very Low",
                "water_retention": "Very Low",
                "nutrient_content": "Low (except for some minerals)"
            },
            "cultivation_practices": """
            Desert soils are challenging for agriculture due to water scarcity and high temperatures. Drought-resistant crops and efficient irrigation systems are essential for successful farming. Soil amendments and wind breaks are important for improving productivity.
            """,
            "soil_preparation": """
            1. Add organic matter to improve soil structure and water retention
            2. Create windbreaks to prevent soil erosion
            3. Apply gypsum to reclaim saline-sodic soils
            4. Use minimum tillage practices to preserve soil moisture
            """,
            "water_management": """
            Water is the most limiting factor:
            
            - Implement highly efficient irrigation systems like drip irrigation
            - Practice deficit irrigation strategies
            - Apply mulch to reduce evaporation
            - Consider night irrigation to minimize evaporation losses
            - Install rainwater harvesting structures
            """,
            "fertilizer_recommendations": """
            Careful nutrient management is needed:
            
            - Apply organic manures to improve soil structure and fertility
            - Use fertigation for efficient nutrient delivery
            - Split application of fertilizers to minimize losses
            - Apply micronutrients based on soil tests
            """,
            "common_issues": """
            - Wind erosion
            - Extreme water scarcity
            - Soil salinity and sodicity
            - Very low organic matter
            - Formation of hard pans
            - Heat stress on crops
            """
        },
        "Mountain Soil": {
            "description": "Mountain soils are found in the hill and mountain regions. They are generally shallow, stony, and have less developed profiles. The soil varies greatly with altitude, slope, and vegetation cover. These soils are prone to erosion due to steep slopes.",
            "composition": {
                "Sand": 50,
                "Silt": 30,
                "Clay": 20
            },
            "properties": {
                "ph": "5.0-6.5 (Acidic to Slightly Acidic)",
                "organic_matter": "Medium to High (in forested areas)",
                "water_retention": "Variable",
                "nutrient_content": "Variable"
            },
            "cultivation_practices": """
            Mountain soils require careful management practices to prevent erosion. Terracing, contour farming, and crop selection based on slope and altitude are important considerations. These soils can be highly productive for specific crops suited to cooler climates.
            """,
            "soil_preparation": """
            1. Practice terracing on slopes to prevent erosion
            2. Use contour ploughing and bunding
            3. Maintain vegetative cover to prevent erosion
            4. Add organic matter to improve soil fertility
            """,
            "water_management": """
            Water management on slopes is critical:
            
            - Create proper drainage channels
            - Implement rainwater harvesting systems
            - Use mulching to conserve soil moisture
            - Practice bench terracing on steep slopes
            """,
            "fertilizer_recommendations": """
            Mountain soils need specific nutrient management:
            
            - Apply lime to correct soil acidity
            - Use balanced fertilizers based on crop requirements
            - Apply organic manures to improve soil structure
            - Consider foliar application of micronutrients
            """,
            "common_issues": """
            - Soil erosion on slopes
            - Shallow soil depth
            - Stoniness and rockiness
            - Leaching of nutrients
            - Soil acidity in high rainfall areas
            - Limited mechanization potential
            """
        }
    }
    
    # Return detailed information for the requested soil type
    return soil_details.get(soil_type, {"description": "Information not available for this soil type."})

